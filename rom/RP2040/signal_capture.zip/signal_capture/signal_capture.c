#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/irq.h"
#include "pico/multicore.h"
#include "class/cdc/cdc_device.h"
#include "capture.pio.h"
#include "tusb.h"


// ユーザー設定定数 +++++++++++++
// チャンネルの GPIO pin 番号
#define CH0_PIN       (12)
#define CH1_PIN       (13)
#define CH2_PIN       (14)
#define CH3_PIN       (15)
// ++++++++++++++++++++++++++++++

// 固定定数 ---------------------
// 最大チャンネル
#define CH_MAX        (4)
// チャンネル当たりの記録点数
#define LOG_SIZE      (8192)
// 状態定義
#define STATE_INIT    (0)
#define STATE_IDLE    (1)
#define STATE_REC     (2)

// コマンド ---------------------
// コマンドは終端文字なく、一文字とする

// 記録開始コマンド (既に記録開始中なら、記録継続し、NG 返す)
// 戻り値: "OK\r" , "NG\r"
#define COMMAND_REC   ('r')

// 記録停止コマンド
// 戻り値: "OK\r"
#define COMMAND_STOP  ('s')

// 現在の記録状態コマンド
// 戻り値: "OFF\r" , "ON\r"
#define COMMAND_STATE ('x')

// 記録停止中のみ有効な、記録データの読み出しコマンド
//
// 前回記録開始から停止までのデータは、メモリ内部に保存されている
// 次に記録開始するまで、保持され続けている
//
// 戻り値: "[[],[],0,40]\r" => 現在記録中か、有効な記録データが無い場合
// 有効な記録データある場合の戻り値例
// "[[1,0,1],[[123,344,2223,...],[234,...],[699,...]],9800,40]\r"
//
// 4要素のリスト
//   1要素目は、各チャンネルの記録開始時の初期論理値(0:Low/1:High) のリスト
//   2要素目は、記録チャンネル個のリスト※、各リストの数値はエッジ発生の絶対時間 [unit]
//   3要素目は、記録終了時間 [unit]
//   4要素目は、内部1ユニット時間当たりの実時間[nsec] = 40 固定
//
//   ※ リストの数値は、記録開始からの時間(下記ユニット時間) を示す
//      論理値遷移を起こした時間が、昇順にリストになっている
//      時間単位は ユニット時間[unit] と呼称し、1 [unit] = 40 [nsec] (25MHz sampling)
//      無符号32ビット値であり、171 [sec] ほどで一巡する
//      上例では、チャンネル0 の時間情報は [123,334,2223,...]
//      チャンネル1 [234,...]、チャンネル2 [699,...] に相当する
//      記録されるチャンネル数は、下記コマンド 1～4 で記録開始前に設定する
#define COMMAND_GET   ('g')

// 記録を有効にするチャンネル数。チャンネル0 ～ (設定値-1) が記録対象になる。
// 初期値は 2
//
// 戻り値: "OK\r" , "NG\r"
#define COMMAND_CH1   ('1')
#define COMMAND_CH2   ('2')
#define COMMAND_CH3   ('3')
#define COMMAND_CH4   ('4')

// デバッグ用途
// 戻り値: 不定
#define COMMAND_PING  ('P')
// -----------------------------

// 記録データ
struct LogicLog{
  uint8_t  initial_level;
  uint16_t capacity;
  // timelog[0] : bit0 = initial level
  // timelog[1]-: Edge time table
  // timelog[n] が 0 の点は無効データ、[n-1] までが有効データ
  uint32_t timelog[LOG_SIZE];
};
static volatile struct LogicLog g_log[CH_MAX];
static uint32_t g_last_time = 0;

static const uint8_t itf = 1; // CDC1 固定
// 記録を有効にするチャンネル数。次の記録開始時に適用される。
static uint8_t g_setting_size = 2;
// 現在記録されている、有効なチャンネル数
static uint8_t g_log_size = 2;
// DMAのメモリ満タン警告フラグ
static volatile bool dma_complete_flag = false;

static void writeLog(void);
static void write_str(const char s[]);
static void clear_log(struct LogicLog log[], uint8_t channel);

static const uint8_t CH_PIN[CH_MAX] = {CH0_PIN, CH1_PIN, CH2_PIN, CH3_PIN};

int signal_capture() {
    // 状態変数
    uint8_t now_state = STATE_INIT;
    uint8_t rbuf[1];
    int c = 0;
    pio_add_program(pio0, &capture_program);

    while(1){
        //tud_task();
        c = 0;
        if (tud_cdc_n_available(itf)) {
            tud_cdc_n_read(1, &rbuf, 1);
            c = rbuf[0];
        }

        if(c > 0){
            switch(c){
            case COMMAND_REC:
                if(now_state == STATE_IDLE || now_state == STATE_INIT){
                    now_state = STATE_REC;
                    // 記録を有効にするチャンネル数を設定
                    g_log_size = g_setting_size;
                    // 記録チャンネル毎に PIO を割り当てて、時間計測
                    for(uint8_t i=0; i < g_log_size; ++i){
                        g_log[i].capacity = LOG_SIZE;
                        clear_log((struct LogicLog *) g_log, i);
                        // PIO 初期化 (capture.pio.h)
                        if(i == g_log_size-1){
                            // 最後の初期化チャンネルがマスター PIO になり、全てのチャンネルの PIO を再開させる。
                            capture_enable(pio0, i, CH_PIN[i], true, (uint32_t *) (g_log[i].timelog), (uint16_t) (g_log[i].capacity));                    
                        }
                        else{
                            // 最後でないチャンネルの PIO は、初期化後一時停止状態になる。
                            capture_enable(pio0, i, CH_PIN[i], false, (uint32_t *) (g_log[i].timelog), (uint16_t) (g_log[i].capacity));
                        }
                    }
                    // DMA が満タンになったら、DMA 割込み内でフラグを立てる
                    dma_complete_flag = false;
                    write_str("OK\r");
                    tud_cdc_n_write_flush(itf);
                }
                else{
                    // 既に記録開始している
                    write_str("NG\r");
                    tud_cdc_n_write_flush(itf);
                }
                break;
            case COMMAND_STOP:
                if(now_state == STATE_REC){
                    for(uint8_t i=0; i < g_log_size; ++i){
                        // PIO 停止 (capture.pio.h)
                        capture_disable(pio0, i);
                    }
                    // 記録終了時間を取得 (capture.pio.h)
                    g_last_time = get_counter(pio0, 0);
                    now_state = STATE_IDLE;
                    // 初期論理値を確定
                    for(uint8_t i=0; i < g_log_size; ++i){
                        g_log[i].initial_level = g_log[i].timelog[0] & 0x01;
                    }
                }
                // いずれの状態でも必ず停止するので戻り値は "OK\r".
                write_str("OK\r");
                tud_cdc_n_write_flush(itf);
                break;
            case COMMAND_STATE:
                if(now_state == STATE_IDLE || now_state == STATE_INIT){
                    write_str("OFF\r");
                    tud_cdc_n_write_flush(itf);
                }
                else{
                    write_str("ON\r");
                    tud_cdc_n_write_flush(itf);
                }
                break;
            case COMMAND_CH1:
            case COMMAND_CH2:
            case COMMAND_CH3:
            case COMMAND_CH4:
                if(now_state == STATE_IDLE || now_state == STATE_INIT){
                    // チャンネル数を数値にして、次回記録時に記録チャンネル数反映
                    g_setting_size = c - COMMAND_CH1 + 1;
                    write_str("OK\r");
                    tud_cdc_n_write_flush(itf);
                }
                else{
                    write_str("NG\r");
                    tud_cdc_n_write_flush(itf);
                }
                break;
            case COMMAND_GET:
                if(now_state == STATE_IDLE){
                    writeLog();
                }
                else{
                    write_str("[[],[],0,40]\r");
                    tud_cdc_n_write_flush(itf);
                }
                break;
            case COMMAND_PING:
                // Do nothing
                break;
            default:
                // Do nothing
                break;
            }
        }

        // いずれかのチャンネルの DMA転送先データが満杯になったら、記録自動終了
        if(now_state == STATE_REC && dma_complete_flag){
            for(uint8_t i=0; i < g_log_size; ++i){
                // PIO 停止 (capture.pio.h)
                capture_disable(pio0, i);
            }
            // 記録終了時間を取得 (capture.pio.h)
            g_last_time = get_counter(pio0, 0);
            now_state = STATE_IDLE;
            // 初期論理値を確定
            for(uint8_t i=0; i < g_log_size; ++i){
                g_log[i].initial_level = g_log[i].timelog[0] & 0x01;
            }
        }
    }
}

void dma_handler(void){
    // Clear DMA IRQ0 for all channel(0-3)
    //
    // Equivalent to the next statement
    // for(uint8_t i=0; i < g_log_size; ++i){
    //    dma_channel_acknowledge_irq0(i);
    // }
    dma_hw->ints0 = 0x0F;
    dma_complete_flag = true;
}

static void writeLog(void){
  write_str("[[");
  for(uint8_t i=0; i < g_log_size; ++i){
    if(i != g_log_size-1){
        write_str(g_log[i].initial_level ? "1,": "0,");
    }
    else{
        write_str(g_log[i].initial_level ? "1],[": "0],[");
    }
  }
  for(uint8_t i=0; i < g_log_size; ++i){
    write_str("[");
    if(g_log[i].timelog[1] != 0){
        // 時刻0 がカウンタ値 0xFFFFFFFF の、減算型カウンタなので、時刻反転
        for(uint16_t j=1; j < g_log[i].capacity; ++j){
            if(j == g_log[i].capacity-1){
                char buf[32];
                int len = snprintf(buf, sizeof(buf), "%lu", 0xFFFFFFFF - g_log[i].timelog[j]);
                tud_cdc_n_write(itf, buf, len);
                break;
            }
            else if(g_log[i].timelog[j+1] ==0){
                char buf[32];
                int len = snprintf(buf, sizeof(buf), "%lu", 0xFFFFFFFF - g_log[i].timelog[j]);
                tud_cdc_n_write(itf, buf, len);
                break;
            }
            else{
                char buf[32];
                int len = snprintf(buf, sizeof(buf), "%lu,", 0xFFFFFFFF - g_log[i].timelog[j]);
                tud_cdc_n_write(itf, buf, len);
            }
        }
    }
    write_str("]");
    if(i != g_log_size-1){
      write_str(",");
    }
  }
  write_str("]");

  char buf[32];
  
  int len = snprintf(buf, sizeof(buf), ",%lu,40]\r", 0xFFFFFFFF - g_last_time);
  tud_cdc_n_write(itf, buf, len);
  tud_cdc_n_write_flush(itf);
}

static void write_str(const char s[]){
    tud_cdc_n_write_str(itf, s);
}

static void clear_log(struct LogicLog log[], uint8_t channel){
    for(uint16_t i=0; i < LOG_SIZE; ++i){
        log[channel].timelog[i] = 0;
    }
}

