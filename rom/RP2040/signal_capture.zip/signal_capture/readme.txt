micropython一式をダウンロードして各種ファイルを指定のディレクトリに配置
# MicroPythonリポジトリを取得
git clone https://github.com/micropython/micropython.git
cd micropython
# サブモジュールを取得
git submodule update --init

..\micropython\ports\rp2\main.c
..\micropython\ports\rp2\signal_capture.c
..\micropython\ports\rp2\CMakeLists.txt
..\micropython\ports\rp2\pio
..\micropython\shared\tinyusb\mp_usbd.h
..\micropython\shared\tinyusb\mp_usbd_cdc.c
..\micropython\shared\tinyusb\mp_usbd_descriptor.c
..\micropython\shared\tinyusb\mp_usbd_runtime.c
..\micropython\shared\tinyusb\tusb_config.h

以下のコマンドでビルドする。
cd ~/micropython/ports/rp2
make clean
make distclean
cd ~/micropython
git submodule update --init --recursive
make -C ports/rp2 BOARD=RPI_PICO

