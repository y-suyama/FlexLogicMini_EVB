//=======================================================
//  Company name        : 
//  Date                : 
//  File Name           : FlexLogicMini_top.sv
//  Project Name        : 
//  Coding              : suyama
//  Rev.                : 1.0
//
//=======================================================
// Import
//=======================================================
//=======================================================
// Module
//=======================================================
//`default_nettype none
module FlexLogicMini_top(
    // Clock, Reset
    input  logic CLK12M,
    input  logic RESET_N,
    // MCU Interrupt
    output logic IRQ_FPGA,
    // MCU SPI Interface
    input  logic SPI0_CLK,
    input  logic SPI0_CS_N,
    input  logic SPI0_MOSI,
    output logic SPI0_MISO,
    // Pin Header Signal
    output  logic FPGA_IO1,
    output  logic FPGA_IO2,
    output  logic FPGA_IO3,
    output  logic FPGA_IO4,
    output  logic FPGA_IO5
);
//=======================================================
//  PARAMETER declarations
//=======================================================
// none
//=======================================================
//  Internal Signal
//=======================================================
logic n_clk48M;
logic n_clk400k;
logic n_clk200k;
logic n_clk1M;
// SPI Slave Signal
wire  n_spi0_miso;
logic [ 8:0] n_efbpll0_bus_i;
logic [16:0] n_efbpll0_bus_o;

logic [16:0] n_pll_bus_o;
logic [ 8:0] n_pll_bus_i;
logic [ 7:0] address;

//=======================================================
//  assign
//=======================================================
assign FPGA_IO1 = n_clk48M;
assign FPGA_IO2 = n_clk400k;
assign FPGA_IO3 = n_clk200k;
assign FPGA_IO4 = n_clk1M;
assign FPGA_IO5 = 1'b0;

// SPI Slave Signal
assign SPI0_MISO   = n_spi0_miso;
//assign IRQ_FPGA    = 1'bz;

//=======================================================
//  Structural coding
//=======================================================
// EFB SPI Slave Hard Macro 
EFB_SPI u0 ( 
    .wb_clk_i(n_clk48M),
    .wb_rst_i(RESET_N),
    .wb_cyc_i(n_efbpll0_bus_o[16]),
    .wb_stb_i(n_efbpll0_bus_o[14]),
    .wb_we_i(n_efbpll0_bus_o[13]),
    .wb_adr_i(n_efbpll0_bus_o[12:8]),
    .wb_dat_i(n_efbpll0_bus_o[7:0]),
    .wb_dat_o(n_efbpll0_bus_i[8:1]),
    .wb_ack_o(n_efbpll0_bus_i[0]),
    // SPI Interface
    .spi_clk(SPI0_CLK ),
    .spi_miso(n_spi0_miso ),
    .spi_mosi(SPI0_MOSI ),
    .spi_scsn(SPI0_CS_N ),
    .spi_irq(IRQ_FPGA),
    // PLL BUS
    .pll0_bus_i(n_pll_bus_i),
    .pll0_bus_o(n_pll_bus_o)
);

// PLL(IP Express)
PLL u1(
    .CLKI(CLK12M),
    // Wishbone BUS
    .PLLCLK(n_pll_bus_o[16]),    // pll_bus_o[16]
    .PLLRST(n_pll_bus_o[15]),    // pll_bus_o[15]
    .PLLSTB(n_pll_bus_o[14]),    // pll_bus_o[14]
    .PLLWE(n_pll_bus_o[13]),     // pll_bus_o[13]
    .PLLDATI(n_pll_bus_o[7:0]),  // pll_bus_o[7:0]
    .PLLADDR(n_pll_bus_o[12:8]), // pll_bus_o[12:8]
    .PLLDATO(n_pll_bus_i[ 8:1]), // pll_bus_i[8:1]
    .PLLACK(n_pll_bus_i[0]),     // pll_bus_i[0]
    // PLL Output Signal
    .CLKOP(n_clk48M),
    .CLKOS(n_clk400k),
    .CLKOS2(n_clk200k),
    .CLKOS3(n_clk1M)
    );

   // WISHBONE control module instantiation           
wb_ctrl u2 (
    // Wishbone BUS
    .wb_clk_i  (n_clk48M ),
    .wb_rst_i  (RESET_N),
    .wb_cyc_i  (n_efbpll0_bus_o[16]),
    .wb_stb_i  (n_efbpll0_bus_o[14]),
    .wb_we_i   (n_efbpll0_bus_o[13]),
    .wb_adr_i  (n_efbpll0_bus_o[12:8]),
    .wb_dat_i  (n_efbpll0_bus_o[7:0]),
    .wb_dat_o  (n_efbpll0_bus_i[8:1]),
    .wb_ack_o  (n_efbpll0_bus_i[0]),
    .address   (address),
    .wr_en     (wr_en),
    .wr_data   (wr_data),
    .rd_en     (rd_en),    
    .rd_data   (rd_data),
    .xfer_done (wb_xfer_done),
    .xfer_req  (wb_xfer_req)
    );   

main_ctrl u3 (
    .CLK         (n_clk48M),
    .RESET_N     (RESET_N),
    .spi_csn     (SPI0_CS_N),
    .address     (address),
    .wr_en       (wr_en),
    .wr_data     (wr_data),
    .rd_en       (rd_en),
    .rd_data     (rd_data),
    .wb_xfer_done(wb_xfer_done),
    .wb_xfer_req (wb_xfer_req)
    );

wb_ctrl u4 (
    .wb_clk_i(n_clk48M), // WISHBONE clock
    .wb_rst_i(RESET_N), // WISHBONE reset
    .wb_cyc_i(n_efbpll0_bus_o[16]), // WISHBONE bus cycle
    .wb_stb_i(n_efbpll0_bus_o[14]), // WISHBONE strobe
    .wb_we_i(n_efbpll0_bus_o[13]),  // WISHBONE write/read control
    .wb_adr_i(n_efbpll0_bus_o[12:8]), // WISHBONE address
    .wb_dat_i(n_efbpll0_bus_o[7:0]), // WISHBONE input data
    .wb_dat_o(n_efbpll0_bus_i[7:0]), // WISHBONE output data
    .wb_ack_o(n_efbpll0_bus_i[0]), // WISHBONE transfer acknowledge
    .address(address),  // Local address
    .wr_en(wr_en),    // Local write enable
    .wr_data(wr_data),  // Local write data
    .rd_en(rd_en),    // Local read enable
    .rd_data(rd_data),  // Local read data
    .xfer_done(wb_xfer_done),// WISHBONE transfer done
    .xfer_req(wb_xfer_req)  // WISHBONE transfer request
    );

endmodule
//`default_nettype wire