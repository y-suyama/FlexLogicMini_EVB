//=======================================================
//  Company name        : 
//  Date                : 
//  File Name           : main_ctrl.sv
//  Project Name        : 
//  Coding              : suyama
//  Rev.                : 1.0
//
//=======================================================
// Import
//=======================================================
//=======================================================
// Module
//=======================================================
`timescale 1 ns/ 1 ps
module main_ctrl(                                                    
  input  logic       CLK,          // System clock
  input  logic       RESET_N,      // System reset
  input  logic       spi_csn,      // Hard SPI chip-select (active low)
  output logic [7:0] address,      // Local address for the WISHBONE interface
  output logic       wr_en,        // Local write enable for the WISHBONE interface
  output logic [7:0] wr_data,      // Local write data for the WISHBONE interface        
  output logic       rd_en,        // Local read enable for the WISHBONE interface          
  input  logic [7:0] rd_data,      // Local read data for the WISHBONE interface          
  input  logic       wb_xfer_done, // WISHBONE transfer done    
  input  logic       wb_xfer_req   // WISHBONE transfer request 
  );
//=======================================================
//  PARAMETER declarations
//=======================================================
  // The definitions for SPI EFB register address
  `define SPITXDR 8'h59 // 送信データ
  `define SPISR   8'h5A // ステータス（TIP,TRDY,RRDY,ROE,MDF）
  `define SPIRXDR 8'h5B // 受信データ
  // The definitions for the state values of the main state machine
  `define S_IDLE      4'h0
  `define S_RXDR_RD   4'h1
  `define S_TXDR_WR   4'h2
  `define S_CMD_ST    4'h3
  `define S_CMD_LD    4'h4
  `define S_CMD_DEC   4'h5
  `define S_TXDR_WR1  4'h6
  `define S_ADDR_ST   4'h7
  `define S_ADDR_LD   4'h8
  `define S_WDATA_ST  4'h9
  `define S_DATA_WR   4'hA  
  `define S_DATA_RD   4'hB    
  `define S_REG_RD    4'hC    
  // The definitions for the SPI command values of the reference design
  `define C_PLL_READ   8'h06
  `define C_PLL_WRITE  8'h04

  // The definitions for the slim version of the SPI command values
  `define PLL_READ   4'h0  
  `define PLL_WRITE  4'h1
  `define INVALID    4'hF
   parameter REVISION_ID = 8'h01;       
//=======================================================
//  Internal Signal
//=======================================================      
  logic [3:0] main_sm;           // The state register of the main state machine
  logic       spi_csn_buf0_p;    // The postive-egde sampling of spi_csn
  logic       spi_csn_buf1_p;    // The postive-egde sampling of spi_csn_buf0_p 
  logic       spi_csn_buf2_p;    // The postive-egde sampling of spi_csn_buf1_p
  logic       spi_cmd_start;     // A new SPI command start
  logic       spi_cmd_start_reg; // The buffer of a new SPI command start
  logic       spi_idle;          // SPI IDLE signal    
  logic [3:0] spi_cmd;           // The slim buffer version of the SPI command used for the performance 
  logic [7:0] pll_reg;           // PLL Register
  logic [7:0] pll_data;          // PLL data
  logic       spi_rx_rdy;        // SPI receive ready    
  logic       spi_tx_rdy;        // SPI transmit ready             
  logic       spi_xfer_done;     // SPI transmitting complete (1: complete, 0: in progress)
//=======================================================
//  assign
//=======================================================
  // Generate SPI command start signal
  assign spi_cmd_start = (spi_csn_buf2_p & ~spi_csn_buf1_p) | spi_cmd_start_reg; // CS falling edge or spi_cmd_start_reg
  assign spi_xfer_done = (~spi_csn_buf2_p & spi_csn_buf1_p) | spi_idle;          // CS rising edge or spi_idle        
  assign spi_rx_rdy    = rd_data[3] ? 1'b1 : 1'b0;
  assign spi_tx_rdy    = rd_data[4] ? 1'b1 : 1'b0;
//=======================================================
//  Structural coding
//=======================================================            
  // Bufferring spi_csn with postive edge                    
  always @(posedge CLK or negedge RESET_N)
    if (!RESET_N)
      spi_csn_buf0_p <= 1'b1;
    else
      spi_csn_buf0_p <= spi_csn;
            
  // Bufferring spi_csn_buf0_p with postive edge                    
  always @(posedge CLK or negedge RESET_N)
    if (!RESET_N)
      spi_csn_buf1_p <= 1'b1;
    else
      spi_csn_buf1_p <= spi_csn_buf0_p;
  // Bufferring spi_csn_buf1_p with postive edge 
  always @(posedge CLK or negedge RESET_N)
    if (!RESET_N)
      spi_csn_buf2_p <= 1'b1;
    else
      spi_csn_buf2_p <= spi_csn_buf1_p;
     
  // Generate SPI command start buffer signal                 
  always @(posedge CLK or negedge RESET_N)
    if (!RESET_N)
      spi_cmd_start_reg <= 1'b0;
    else
      if (spi_csn_buf2_p && !spi_csn_buf1_p) // CS falling edge
        spi_cmd_start_reg <= 1'b1;
      else if (main_sm == `S_IDLE || main_sm == `S_RXDR_RD || (!spi_csn_buf2_p && spi_csn_buf1_p))
        spi_cmd_start_reg <= 1'b0;
  // spi_idle will be asserted between spi_csn de-asserted and main_sm == `S_IDLE
  always @(posedge CLK or negedge RESET_N)
    if (!RESET_N)
      spi_idle <= 1'b0;
    else 
      if (spi_csn_buf1_p)
        spi_idle <= 1'b1;
      else if (main_sm == `S_IDLE)   
        spi_idle <= 1'b0;

    //The main state machine with its output registers      
   always @(posedge CLK or negedge RESET_N)
     if (!RESET_N) begin
       main_sm  <= `S_IDLE;
       spi_cmd  <= `PLL_READ;
       rd_en    <= 1'b0;
       wr_en    <= 1'b0;
       address  <= 8'h59;
       wr_data  <= 8'd0;
       pll_reg  <= 8'd0;
       pll_data <= 8'd0;
     end
     else begin
       rd_en   <= 1'b0;
       wr_en   <= 1'b0;
       address <= 8'h59;
        
      case (main_sm)
        // IDEL state
       `S_IDLE:
         if (spi_cmd_start && wb_xfer_req) begin
           main_sm <= `S_RXDR_RD;            // Go to `S_RSDR_RD state when a new SPI command starts and WISHBONE is ready to transfer
           rd_en   <= 1'b1;                        
           address <= `SPIRXDR;
         end
        // Read SPI EFB RXDR register first to get ready to read the SPI command next
       `S_RXDR_RD:
         if (wb_xfer_done) begin
           main_sm <= `S_TXDR_WR;            // Go to `S_TXDR_WR state when the RXDR register read is done
           wr_en   <= 1'b1; 
           address <= `SPITXDR; // 0x00 write
          end
         // Write dummy data to the SPI EFB TXDR register in order to write next data to the register correctly       
        `S_TXDR_WR:
          if (wb_xfer_done) begin                
            main_sm <= `S_CMD_ST;             // Go to `S_CMD_ST state when the TXDR register write is done
            rd_en   <= 1'b1;
            address <= `SPISR;
          end
         // Wait for the SPI command is ready in the RXDR register                                              
        `S_CMD_ST:   begin 
          if (wb_xfer_done && spi_rx_rdy) begin  
            main_sm <= `S_CMD_LD;          // Go to `S_CMD_LD state when the SPI command is ready in the RXDR register
            rd_en   <= 1'b1;                        
            address <= `SPIRXDR; // SPI MOSI(CMD)
          end
          else if (wb_xfer_done && spi_tx_rdy) begin
            main_sm <= `S_TXDR_WR;         // Go to `S_TXDR_WR state to rewrite the TXDR register when SPI transmit is ready
            wr_en   <= 1'b1; 
            address <= `SPITXDR;                              
          end
          else if (wb_xfer_done) begin
            rd_en   <= 1'b1;                 // Otherwise, keep read SR register in the current state
            address <= `SPISR;
          end  
        end 
         // Load the SPI command to improve the performance because the path delay from the RXDR register is very big 
        `S_CMD_LD:   
          if (wb_xfer_done) begin
            main_sm <= `S_CMD_DEC;            // Go to `S_CMD_DEC state when the RXDR register read is done
            case (rd_data)
              `C_PLL_READ:   spi_cmd <= `PLL_READ;   
              `C_PLL_WRITE:  spi_cmd <= `PLL_WRITE;  
              default:       spi_cmd <= `INVALID;
            endcase
         end
         // Decode the SPI command              
        `S_CMD_DEC:  begin
          case (spi_cmd)
            `PLL_READ:     begin 
              main_sm <= `S_TXDR_WR1;
              wr_en   <= 1'b1; 
              address <= `SPITXDR; // 0x00 write
            end
            `PLL_WRITE:     begin 
              main_sm <= `S_TXDR_WR1;
              wr_en   <= 1'b1; 
              address <= `SPITXDR; // 0x00 write
            end
            default:
              main_sm <= `S_IDLE;        // Go to `S_IDLE state when the SPI command is illegal
          endcase
          if (spi_xfer_done) begin        
            main_sm <= `S_IDLE;               // Go to `S_IDLE state when the current SPI transaction is ended
            rd_en   <= 1'b0;
            wr_en   <= 1'b0;
          end                           
                                                       
        end   
          // For GPIO/memory commands, write dummy data to the SPI EFB TXDR register in order to write next data to the register correctly.
        `S_TXDR_WR1:
          if (wb_xfer_done) begin
            main_sm <= `S_ADDR_ST;               // Go to `S_ADDR_ST state when the TXDR register write is done
            rd_en   <= 1'b1;
            address <= `SPISR;
          end
          // For GPIO/memory commands, wait for the address ready in the RXDR register.
         `S_ADDR_ST:  begin 
           if (wb_xfer_done && spi_rx_rdy) begin
//             main_sm <= `S_ADDR_LD;           // Go to `S_ADDR_LD state when the address is ready in the RXDR register
             main_sm <= `S_REG_RD;           // Go to `S_REG_RD state when the address is ready in the RXDR register
             rd_en   <= 1'b1;                        
             address <= `SPIRXDR; // SPIMOSI(Register Address)
             pll_reg <= rd_data;
             if (spi_xfer_done) begin
                main_sm <= `S_IDLE;           // Go to `S_IDLE state when the current SPI transaction is complete
                rd_en   <= 1'b0;
             end   
           end
           else if (wb_xfer_done && spi_xfer_done)   
             main_sm <= `S_IDLE;               // Go to `S_IDLE state when the SPI transfer is complete
           else if (wb_xfer_done && spi_tx_rdy) begin
              main_sm <= `S_TXDR_WR1;           // Go to `S_TXDR_WR1 state to rewrite the TXDR register when SPI transmit is ready
              wr_en   <= 1'b1; 
              address <= `SPITXDR; 
           end
           else if (wb_xfer_done) begin
             rd_en   <= 1'b1;                    // Otherwise, keep read SR register in the current state
             address <= `SPISR;
           end  
         end
          `S_REG_RD:
            if (wb_xfer_done) begin
               main_sm  <= `S_ADDR_LD;     // Go to `S_ADDR_LD state when the SPI read data is ready in the RXDR register
               rd_en    <= 1'b1;                        
               address  <= pll_reg;
            end
          // For PLL Read/Write commands, load address.
         `S_ADDR_LD:  
           if (wb_xfer_done) begin
              case (spi_cmd)
              `PLL_READ:     begin 
                  main_sm   <= `S_DATA_RD;  // Go to `S_DATA_RD state when the SPI command is Read GPI
                  rd_en     <= 1'b1; 
                  address   <= `SPISR; // Register Address
                  pll_data  <= rd_data;
               end
              `PLL_WRITE:     begin 
                  main_sm  <= `S_WDATA_ST; // Go to `S_WDATA_ST state when the SPI command is Write PLL
                  rd_en    <= 1'b1; 
                  address  <= `SPISR; 
               end
              endcase
           end

          // (PLL Write)Wait for the SPI write data ready in the RXDR register       
          `S_WDATA_ST: begin
             if (wb_xfer_done && spi_rx_rdy) begin
                main_sm  <= `S_DATA_WR;            // Go to `S_DATA_WR state when the SPI write data is ready in the RXDR register
                rd_en    <= 1'b1;                        
                address  <= `SPIRXDR; // SPI MOSI(Write Data)
                pll_data <= rd_data; // Write Data
             end
             else if (wb_xfer_done && spi_xfer_done)   
                main_sm <= `S_IDLE;               // Go to `S_IDLE state when the SPI transfer is complete
             else if (wb_xfer_done) begin
                rd_en <= 1'b1;                    // Otherwise, keep read SR register in the current state
                address <= `SPISR;
             end  
          end
          // Load SPI data                             
          `S_DATA_WR:  
          if (wb_xfer_done) begin
            case (spi_cmd) 
              `PLL_WRITE:     begin 
                main_sm   <= `S_IDLE;     // Go to `S_IDLE state when the SPI command is Write GPO
                wr_en     <= 1'b1;
                address   <= pll_reg;
                wr_data   <= pll_data;
              end
            endcase
          end
          // (PLL Read)Write the SPI read data to the TXDR register    
          `S_DATA_RD:  begin
          if (wb_xfer_done && spi_tx_rdy) begin
                   main_sm <= `S_IDLE;     // Go to `S_IDLE state when the SPI command is Read GPI
                   wr_en   <= 1'b1; 
                   wr_data <= pll_data;
                   address <= `SPITXDR; 
            if (spi_xfer_done) begin
                 main_sm <= `S_IDLE;               // Go to `S_IDLE state when the current SPI transaction is complete
                 wr_en   <= 1'b0;
            end   
            else if (wb_xfer_done && spi_xfer_done)   
              main_sm <= `S_IDLE;                  // Go to `S_IDLE state when the current SPI transaction is complete
            else if (wb_xfer_done) begin
                rd_en   <= 1'b1;
                address <= `SPISR;
            end   
          end
        end
        default: main_sm <= `S_IDLE;                                         
      endcase
     end          
endmodule
    
    