
#Begin clock constraint
define_clock -name CLK12M -period 83.33 [get_ports CLK12M]
#End clock constraint
