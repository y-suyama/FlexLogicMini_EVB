#-- Lattice Semiconductor Corporation Ltd.
#-- Synplify OEM project file

#device options
set_option -technology MACHXO2
set_option -part LCMXO2_1200HC
set_option -package SG32C
set_option -speed_grade -4

#compilation/mapping options
set_option -symbolic_fsm_compiler true
set_option -resource_sharing true

#use verilog 2001 standard option
set_option -vlog_std v2001

#map options
set_option -frequency 100
set_option -maxfan 1000
set_option -auto_constrain_io 0
set_option -disable_io_insertion false
set_option -retiming false; set_option -pipe true
set_option -force_gsr false
set_option -compiler_compatible 0
set_option -dup false

set_option -default_enum_encoding default

#simulation options


#timing analysis options



#automatic place and route (vendor) options
set_option -write_apr_constraint 1

#synplifyPro options
set_option -fix_gated_and_generated_clocks 1
set_option -update_models_cp 0
set_option -resolve_multiple_driver 0


set_option -seqshift_no_replicate 0

#-- add_file options
set_option -include_path {C:/work_design/fpga_prj/FlexLogicMini_V2}
add_file -verilog -vlog_std v2001 {C:/work_design/fpga_prj/FlexLogicMini_V2/IP/EFB/EFB_SPI.v}
add_file -verilog -vlog_std v2001 {C:/work_design/fpga_prj/FlexLogicMini_V2/IP/PLL/PLL.v}
add_file -verilog -vlog_std sysv {C:/work_design/fpga_prj/FlexLogicMini_V2/impl1/source/FlexLogicMini_top.sv}
add_file -verilog -vlog_std sysv {C:/work_design/fpga_prj/FlexLogicMini_V2/impl1/source/main_ctrl.sv}
add_file -verilog -vlog_std sysv {C:/work_design/fpga_prj/FlexLogicMini_V2/impl1/source/wb_ctrl.sv}

#-- top module name
set_option -top_module FlexLogicMini_top

#-- set result format/file last
project -result_file {C:/work_design/fpga_prj/FlexLogicMini_V2/impl1/FlexLogicMini_impl1.edi}

#-- error message log file
project -log_file {FlexLogicMini_impl1.srf}

#-- set any command lines input by customer


#-- run Synplify with 'arrange HDL file'
project -run -clean
