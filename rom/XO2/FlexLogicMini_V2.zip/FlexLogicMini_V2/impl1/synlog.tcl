run_tcl -fg FlexLogicMini_impl1_synplify.tcl
