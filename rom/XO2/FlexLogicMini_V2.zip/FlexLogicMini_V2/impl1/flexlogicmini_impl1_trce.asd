[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = - (-);
Fmax_1 = 86.655 MHz (48.000 MHz);
Fmax_2 = - (-);
Fmax_3 = - (-);
Fmax_4 = - (-);
Failed = 0 (Total 5);
Clock_ports = 3;
Clock_nets = 4;
; Hold Analysis
Fmax_0 = - (-);
Fmax_1 = 0.304 ns (0.000 ns);
Fmax_2 = - (-);
Fmax_3 = - (-);
Fmax_4 = - (-);
Failed = 0 (Total 5);
Clock_ports = 3;
Clock_nets = 4;
